insert into employee
values(1001,'Sravan', 'PM', 1002);

insert into employee
values(1002,'Deepesh', 'DM', 1003);

insert into employee
values(1003,'Suman', 'DP', 1004);

insert into employee (EMP_ID, NAME, ROLE)
values(1004,'Harish', 'BRM');

insert into employee
values(1005,'Javeed', 'PMO', 1001);

